package com.example.demo.modules;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Wallet {
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String walletHolderName;
	private String walletEmail;
	private long walletAmount;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getWalletHolderName() {
		return walletHolderName;
	}
	public void setWalletHolderName(String walletHolderName) {
		this.walletHolderName = walletHolderName;
	}
	public String getWalletEmail() {
		return walletEmail;
	}
	public void setWalletEmail(String walletEmail) {
		this.walletEmail = walletEmail;
	}
	public long getWalletAmount() {
		return walletAmount;
	}
	public void setWalletAmount(long walletAmount) {
		this.walletAmount = walletAmount;
	}
	@Override
	public String toString() {
		return "Wallet [id=" + id + ", walletHolderName=" + walletHolderName + ", walletEmail=" + walletEmail
				+ ", walletAmount=" + walletAmount + "]";
	}
	
	
	
	
}
