package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.Applicant;

public interface ApplicantService {

	void addApplicant(Applicant a);
	List<Applicant> getappli();
	
	void deleteApplicant(int id);

	Applicant EditApplicant(int id);
	
	
	Applicant Checklogin(String email);
	
	
	
	
	

}
