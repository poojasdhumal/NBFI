package com.example.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.EmiDetails;
import com.example.demo.repo.emaiDetailsRepo;
import com.example.demo.service.emiDetailsServ;

@Service
public class emiDetailsDao implements emiDetailsServ 
{
	
	@Autowired
	emaiDetailsRepo wall;

	@Override
	public void send(EmiDetails details) 
	{
		wall.save(details);
		
	}

	@Override
	public EmiDetails getSingleEmi(int id) 
	{
		
		return wall.getById(id);
	}

	@Override
	public void set(EmiDetails details) 
	{
		
		wall.updateEmiStatusById(details.getEmiStatus(),details.getId(),details.getPaidDate());
		
	}

}
