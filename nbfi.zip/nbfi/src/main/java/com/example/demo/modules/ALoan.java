package com.example.demo.modules;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class ALoan {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	private String email;
	private String phone;
	private String address;
	private String occupation;
	private String mariatalstatus;
	private String income;
	private String loanamount;
	private String duration;
	private String durationunit;
	private String rate;
	private String payableamount;
	private String peremiamount;
	private String purposeofloan;
	private String dependentName;
	private String dependentadhar;
	private String dependentpan;
	private String loanstatus;
	private String paymentstatus;
	private String suitableEmiDate;
	private String date;
	
	@OneToMany(mappedBy = "aLoan")
    private List<EmiDetails> emiDetails;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getMariatalstatus() {
		return mariatalstatus;
	}

	public void setMariatalstatus(String mariatalstatus) {
		this.mariatalstatus = mariatalstatus;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getLoanamount() {
		return loanamount;
	}

	public void setLoanamount(String loanamount) {
		this.loanamount = loanamount;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getDurationunit() {
		return durationunit;
	}

	public void setDurationunit(String durationunit) {
		this.durationunit = durationunit;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getPayableamount() {
		return payableamount;
	}

	public void setPayableamount(String payableamount) {
		this.payableamount = payableamount;
	}

	public String getPeremiamount() {
		return peremiamount;
	}

	public void setPeremiamount(String peremiamount) {
		this.peremiamount = peremiamount;
	}

	public String getPurposeofloan() {
		return purposeofloan;
	}

	public void setPurposeofloan(String purposeofloan) {
		this.purposeofloan = purposeofloan;
	}

	public String getDependentName() {
		return dependentName;
	}

	public void setDependentName(String dependentName) {
		this.dependentName = dependentName;
	}

	public String getDependentadhar() {
		return dependentadhar;
	}

	public void setDependentadhar(String dependentadhar) {
		this.dependentadhar = dependentadhar;
	}

	public String getDependentpan() {
		return dependentpan;
	}

	public void setDependentpan(String dependentpan) {
		this.dependentpan = dependentpan;
	}

	public String getLoanstatus() {
		return loanstatus;
	}

	public void setLoanstatus(String loanstatus) {
		this.loanstatus = loanstatus;
	}

	public String getPaymentstatus() {
		return paymentstatus;
	}

	public void setPaymentstatus(String paymentstatus) {
		this.paymentstatus = paymentstatus;
	}

	public String getSuitableEmiDate() {
		return suitableEmiDate;
	}

	public void setSuitableEmiDate(String suitableEmiDate) {
		this.suitableEmiDate = suitableEmiDate;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<EmiDetails> getEmiDetails() {
		return emiDetails;
	}

	public void setEmiDetails(List<EmiDetails> emiDetails) {
		this.emiDetails = emiDetails;
	}

	@Override
	public String toString() {
		return "ALoan [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", address=" + address
				+ ", occupation=" + occupation + ", mariatalstatus=" + mariatalstatus + ", income=" + income
				+ ", loanamount=" + loanamount + ", duration=" + duration + ", durationunit=" + durationunit + ", rate="
				+ rate + ", payableamount=" + payableamount + ", peremiamount=" + peremiamount + ", purposeofloan="
				+ purposeofloan + ", dependentName=" + dependentName + ", dependentadhar=" + dependentadhar
				+ ", dependentpan=" + dependentpan + ", loanstatus=" + loanstatus + ", paymentstatus=" + paymentstatus
				+ ", suitableEmiDate=" + suitableEmiDate + ", date=" + date + ", emiDetails=" + emiDetails + "]";
	}

	
	

}
