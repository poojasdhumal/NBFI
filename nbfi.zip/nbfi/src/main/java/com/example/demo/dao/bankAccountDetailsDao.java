package com.example.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.bankAccountDetails;
import com.example.demo.repo.bankAccountDetailsRepo;
import com.example.demo.service.bankAccountDeatailsServ;

@Service
public class bankAccountDetailsDao implements bankAccountDeatailsServ
{

	@Autowired
	bankAccountDetailsRepo details;

	@Override
	public void save(bankAccountDetails bankdetails) 
	{
		details.save(bankdetails);
		
	}
	
}
