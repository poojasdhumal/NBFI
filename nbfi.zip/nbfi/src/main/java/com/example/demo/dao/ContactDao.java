package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.Contact;
import com.example.demo.repo.ContactRepo;
import com.example.demo.service.ContactService;

@Service
public class ContactDao implements ContactService {

	@Autowired
	ContactRepo cr;
	
	@Override
	public void cont(Contact c) {
		
		cr.save(c);
	}

	@Override
	public List<Contact> getmsg() {
		
		return cr.findAll();
	}

}