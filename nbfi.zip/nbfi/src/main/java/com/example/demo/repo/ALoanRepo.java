package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.modules.ALoan;

public interface ALoanRepo extends JpaRepository<ALoan,Integer>
{

	List<ALoan> findByLoanstatus(String status);

	List<ALoan> findByLoanstatusAndPaymentstatus(String loanstatus, String paymentstatus);

	List<ALoan> getByEmail(String email);

	List<ALoan> findByEmailAndLoanstatusAndPaymentstatus(String user, String loanStatus, String paymentStatus);

}
