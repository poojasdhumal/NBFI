package com.example.demo.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.modules.EmiDetails;

public interface emaiDetailsRepo extends JpaRepository<EmiDetails,Integer> 
{

	@Modifying
    @Transactional
    @Query("UPDATE EmiDetails e SET e.emiStatus = :emiStatus WHERE e.id = :id")
	void updateEmiStatusById(@Param("emiStatus") String emiStatus, @Param("id") int id);

	@Modifying
    @Transactional
    @Query("UPDATE EmiDetails e SET e.emiStatus = :emiStatus ,e.paidDate = :paidDate  WHERE e.id = :id")
	void updateEmiStatusById(@Param("emiStatus") String emiStatus,@Param("id") int id,@Param("paidDate") String paidDate);

}
