package com.example.demo.modules;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class transactions 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Trid;
	private long amount;
	private String transactionid;
	private String sender;
	private String receiver;
	private String transtime;
	private String transdate;
	public int getTrid() {
		return Trid;
	}
	public void setTrid(int trid) {
		Trid = trid;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getTranstime() {
		return transtime;
	}
	public void setTranstime(String transtime) {
		this.transtime = transtime;
	}
	public String getTransdate() {
		return transdate;
	}
	public void setTransdate(String transdate) {
		this.transdate = transdate;
	}
	@Override
	public String toString() {
		return "transactions [Trid=" + Trid + ", amount=" + amount + ", transactionid=" + transactionid + ", sender="
				+ sender + ", receiver=" + receiver + ", transtime=" + transtime + ", transdate=" + transdate + "]";
	}
	
	
	

}
