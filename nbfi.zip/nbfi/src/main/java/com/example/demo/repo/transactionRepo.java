package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.modules.transactions;

@Repository
public interface transactionRepo extends JpaRepository<transactions,Integer> {



	List<transactions> getBySenderOrReceiver(String userEmail,String Email);

}
