package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.transactions;
import com.example.demo.repo.transactionRepo;
import com.example.demo.service.transactionServ;

@Service
public class transactionDao implements transactionServ {
	
	@Autowired
    transactionRepo td;

	@Override
	public void addTransaction(transactions transaction) 
	{
	
		td.save(transaction);
		
	}

	@Override
	public List<transactions> getAllTransactions() 
	{
		
		return td.findAll();
	}

	@Override
	public List<transactions> getSingleTransaction(String userEmail) 
	{
		
		return td.getBySenderOrReceiver(userEmail,userEmail);
	}

}
