package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.Wallet;

public interface WalletFundsService {

	void createWallet(Wallet wall);

	Wallet getAmount(String user);

	List<Wallet> getAllWallets();

}
