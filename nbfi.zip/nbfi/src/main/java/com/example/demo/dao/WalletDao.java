package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.Wallet;
import com.example.demo.repo.WalletRepo;
import com.example.demo.service.WalletFundsService;

@Service
public class WalletDao implements WalletFundsService
{
    @Autowired
	WalletRepo wr;
    
	
	@Override
	public void createWallet(Wallet wall) 
	{
		wr.save(wall);
		
	}


	@Override
	public Wallet getAmount(String user) 
	{
		// TODO Auto-generated method stub
		return wr.getByWalletEmail(user);
	}


	@Override
	public List<Wallet> getAllWallets() {
		
		return  wr.findAll();
	}

}
