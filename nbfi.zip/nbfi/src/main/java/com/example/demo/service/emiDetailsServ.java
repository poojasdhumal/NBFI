package com.example.demo.service;

import com.example.demo.modules.EmiDetails;

public interface emiDetailsServ 
{

	void send(EmiDetails details);

	EmiDetails getSingleEmi(int id);

	void set(EmiDetails details);

	
	
}
