package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.Payment;

public interface PaymentService
{
  void payment(Payment p);
 
  
  List <Payment>getpayment();
  
  void deletedata(int id);
  
}
