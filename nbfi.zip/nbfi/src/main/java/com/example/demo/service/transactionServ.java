package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.transactions;

public interface transactionServ {

	void addTransaction(transactions transaction);

	List<transactions> getAllTransactions();

	List<transactions> getSingleTransaction(String userEmail);

}
