package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.AdminWallet;

public interface AdminWalletService 
{

	void send(AdminWallet wallet);

	List<AdminWallet> getAll();
     
}
