package com.example.demo.controller;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.modules.ALoan;
import com.example.demo.modules.AdminWallet;
import com.example.demo.modules.Applicant;
import com.example.demo.modules.Contact;
import com.example.demo.modules.EmiDetails;
import com.example.demo.modules.Wallet;
import com.example.demo.modules.bankAccountDetails;
import com.example.demo.modules.transactions;
import com.example.demo.service.ALoanService;
import com.example.demo.service.AdminWalletService;
import com.example.demo.service.ApplicantService;
import com.example.demo.service.ContactService;
import com.example.demo.service.PaymentService;
import com.example.demo.service.WalletFundsService;
import com.example.demo.service.approveService;
import com.example.demo.service.bankAccountDeatailsServ;
import com.example.demo.service.emiDetailsServ;
import com.example.demo.service.transactionServ;

@Controller
public class MyController {
	
	public boolean loginMssg=true;
	
	@Autowired
	approveService aps;
	
	@Autowired
    AdminWalletService as;

	@Autowired
	PaymentService prc;
	
	@Autowired
    WalletFundsService wfs;
	
	@Autowired
	ApplicantService asa;
	
	@Autowired
	ALoanService all;
	
	@Autowired
	ContactService cs;
	
	@Autowired
	transactionServ transServ;
	
	@Autowired
	emiDetailsServ EMISServ;
	
	@Autowired
	bankAccountDeatailsServ bankDetails;
	
	

	@RequestMapping("/")
	public String getdata() 
	{
		return "index";	
	}

	@RequestMapping("/NBFC")
	public String Index2() {
		return "index";	
	}

	@RequestMapping("/OurClients")
	public String OurClient() {
		return "OurClients";	
	}
	
	@PostMapping("/Connect")
	public String Contact1(@ModelAttribute("c") Contact c) {
		
		cs.cont(c);
		return "redirect:/NBFC";	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	// user Module
	
	@RequestMapping("/UserRegistration")
	public String User() {
		return "UserReg";	
	}
	
	@PostMapping("/UserR")
	public String UserReg(@ModelAttribute Applicant u,ModelMap m ,Wallet wall) {
		

		wall.setWalletAmount(0);
		wall.setWalletEmail(u.getEmail());
		wall.setWalletHolderName(u.getName());

		wfs.createWallet(wall);
		asa.addApplicant(u);
		
		
		m.addAttribute("mssg", "<script>alert('Registered Succesfully');</script>");
		return "UserLogin";	
	}
	
	@RequestMapping("/UserLogin")
	public String UserLogin()
	{
		
		return "UserLogin";	
		
	}	
	
	
	
	@PostMapping("/UserL")
	public String UserLogin2(@RequestParam("email") String email,@RequestParam("password") String password,ModelMap m,HttpSession s1) 
	{    
		

		Applicant app=asa.Checklogin(email);
		
		if(app!=null && app.getPassword().equals(password)) {
			
			s1.setAttribute("email",email);
			s1.setAttribute("type", "user");
			
			if(loginMssg)
			{
				m.addAttribute("mssg", "<script>alert('Login Succesfully');</script>");
				loginMssg=false;
			}
			
			
			return "index";
		}
		else {
			
			m.put("errorMsg", "Please provide correct email and password !!");
			return "UserLogin";
		}
		
			
	}
	
	@RequestMapping("/apply")
	public String ApplyLoans(HttpSession session,ModelMap m) 
	{
		String getSession=(String) session.getAttribute("email");

		if(getSession!=null)
		{
			Applicant applicant=asa.Checklogin(getSession);
			
			m.addAttribute("app", applicant);
			return "ApplyLoan";	
		}
		return "redirect:/UserLogin";	
		
	}
	
	@PostMapping("/applyingForLoan")
	public String ApplyLoans1(@ModelAttribute("al") ALoan al,ModelMap m) 
	{
		all.getloan(al);
		m.addAttribute("mssg", "<script>alert('Succesfully Applied for Loan');</script>");
		return "index";	
	}

	@RequestMapping("/logout")
	public String LogOut(HttpSession sess) 
	{
		sess.invalidate();
		loginMssg=true;
		return "redirect:/NBFC";	
	}
	
	@GetMapping("/loanStatus")
	public String Contact(ModelMap m , HttpSession sess) {
		
		String email=(String) sess.getAttribute("email");
		
		List<ALoan> c1=all.getLoans(email);
		
		if(c1.size()>0)
		{
			m.addAttribute("c1",c1);
		}else {
			m.addAttribute("mssg","You not yet applied for any loan !!! <a href='apply' >Apply Here</a> ");
		}
		
		
		return "loanStatus";	
	}
	
	@RequestMapping("/MyWallet")
	public String MyAccount(HttpSession Sess,ModelMap m) 
	{
		
		String user=(String)Sess.getAttribute("email");	
		
		Wallet singleWallet=wfs.getAmount(user);		

		m.addAttribute("single", singleWallet);
		
		return "MyWallet";
		
	}
	
	@RequestMapping("/viewAllTransactions")
	public String userTransactions(HttpSession Sess,ModelMap m) 
	{
		String userEmail=(String)Sess.getAttribute("email");
		
		List<transactions> userTransaction=transServ.getSingleTransaction(userEmail);
		
		m.addAttribute("transactions", userTransaction);
		
		return "singleUserTransactions";
		
	}
	
	@GetMapping("/MyRelations")
	public String MyRelations(HttpSession session,ModelMap m)
     {
		
		String user=(String) session.getAttribute("email");
		
		if(user!=null)
		{
			// fetch approved loans
			List<ALoan> approvedLoans=all.getApproverdLoans(user,"Accepted","Distributed");
			
			if(approvedLoans.size()>0)
			{
				m.addAttribute("approved", approvedLoans);
			}else {
				m.addAttribute("mssg","You not yet applied for any loan or Your applied loans Are not approved yet  !!! <a href='apply' >Apply Here</a> ");
			}
			
			
			
			return "myRelations";
		}
		
		return "redirect:/UserLogin";	
					
     }
	
    @GetMapping("/viewSingleRelation")
 	public String ViewSingleRelationDues(@RequestParam("id")int id,HttpSession session,ModelMap m)
      {
 		
 		String user=(String) session.getAttribute("email");
 		
 		if(user!=null)
 		{
 			ALoan singleLoan=all.GetSingle( id);
 			
 			List<EmiDetails> details=singleLoan.getEmiDetails();
 			
 			m.addAttribute("data", details);
 			
 			session.setAttribute("viewSingleRelation", "viewSingleRelation?id="+id);
 			
 			return "viewSingleRelation";
 		}
 		
 		return "redirect:/UserLogin";	
 					
      }
	
      @GetMapping("/viewSingleEmi")
   	  public String viewSingleEmi(@RequestParam("id")int id,HttpSession session,ModelMap m)
        {
   		
	   		String user=(String) session.getAttribute("email");
	   		
	   		if(user!=null)
	   		{
	
	   			EmiDetails singleEmiDetail=EMISServ.getSingleEmi(id);
	   			m.addAttribute("data", singleEmiDetail);
	   			
	   			return "ViewSingleEmi";
	   		}
	   		
	   		return "redirect:/UserLogin";	
   					
        }
	
	
        @GetMapping("/payEmi")
     	public String payEmi(@RequestParam("id")int id,HttpSession session,ModelMap m)
        {
        	
     		
     		String user=(String) session.getAttribute("email");
     		
     		if(user!=null)
     		{

     			EmiDetails singleEmiDetail=EMISServ.getSingleEmi(id);
     			
     			// current date 
  				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
  				
  				LocalDateTime now = LocalDateTime.now();

     			String currentdate=dtf.format(now);
     			String emiDate=singleEmiDetail.getEmiDate();
     			
     			
	     		// Parse the date strings into LocalDate objects
	     		LocalDate currentDate = LocalDate.parse(currentdate, dtf);
	     		LocalDate emiLocalDate = LocalDate.parse(emiDate, dtf);
	
	     		// Calculate the difference in days
	     		long dayDifference = ChronoUnit.DAYS.between(emiLocalDate, currentDate);
	     		
	     		if(dayDifference>0)
	     		{
	     			long OriginalPayableAmount=Integer.parseInt(singleEmiDetail.getaLoan().getPeremiamount());
	     			
	     			
	     			long lateCharges=(long) Math.ceil((OriginalPayableAmount*0.03)*dayDifference);
	     			
	     			long FinalPayableAmount=lateCharges +OriginalPayableAmount;

	     			m.addAttribute("lateCharges", "Late Charges : "+lateCharges+" RS/-");
	     			
	     			m.addAttribute("FinalPayableAmount", FinalPayableAmount);
	     		}
     			
	     		
	   			m.addAttribute("data", singleEmiDetail);
	   			
	   			return "PayEmi";
     		}
     		
     		return "redirect:/UserLogin";	
     					
         }
        
        @PostMapping("/payingEmi")
      	public String payingEmi(@RequestParam("id")int id,@RequestParam("amount")String amount,@RequestParam("date")String date,HttpSession session,@ModelAttribute("transaction") transactions transaction,@ModelAttribute("adminwallet") AdminWallet adminwallet,@ModelAttribute("details") EmiDetails details,ModelMap m)
         {
      		
      		String user=(String) session.getAttribute("email");
      		long emiAmount=Integer.parseInt(amount);
      		
      		if(user!=null)
      		{
      			
      			
      			Wallet singleUserWallet=wfs.getAmount(user);
      			long userWalletBalance=singleUserWallet.getWalletAmount();
      			
      			if(userWalletBalance>=emiAmount)
      			{
      				
      				// current date and time
      				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
      				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss"); 

      				LocalDateTime now = LocalDateTime.now();
      				LocalDateTime now1 = LocalDateTime.now();

      				String currentdate=dtf.format(now);
      				String currenttime=dtf1.format(now1);
      				
      				
      				// generate random number for transaction id
					Random generator = new Random(System. currentTimeMillis()) ;		
					int random=(int) ((generator. nextLong()) % 1000000000);	
					
					// if generate number is negative convert it to positive
					if(random<0){random*=(-1);}
					
					// set transaction Id
					transaction.setTransactionid(Integer.toString(random));
					transaction.setAmount(emiAmount);
					transaction.setSender(user);
					transaction.setReceiver("admin");
					transaction.setTransdate(currentdate);
					transaction.setTranstime(currenttime);
					
					// save transaction
					transServ.addTransaction(transaction);

					
      				// getting  last wallet amount of admin
      				List<AdminWallet> getAll=as.getAll();
      				AdminWallet singleData=getAll.get(getAll.size()-1);		
      				long adminWalletAmount=singleData.getWalletAmount();
      				
      				
      				// add EMI amount in admin wallet
					long lastAdminAmount=adminWalletAmount+emiAmount;				
					adminwallet.setWalletAmount(lastAdminAmount);
					adminwallet.setTransactionAmount(emiAmount);					
					adminwallet.setTransdate(currentdate);
					adminwallet.setTranstime(currenttime);
					
					// save changes of admin wallet
					as.send(adminwallet);
      				
      				// deduct EMI Amount from users wallet
      				userWalletBalance=userWalletBalance-emiAmount;			
      				singleUserWallet.setWalletAmount(userWalletBalance);
      				
      				// save changes of applicant wallet 
					wfs.createWallet(singleUserWallet);
      			
      				// change emi status
					if(date.equals(currentdate))
					{
						details.setEmiStatus("Paid");
					}else {
						details.setEmiStatus("Latepaid");
					}
      				details.setId(id);
      				details.setPaidDate(currentdate);
      				
      				System.out.println("EMI Date: "+date);
      				System.out.println("Paying Date: "+currentdate);
      				
      				// save emi details
      				EMISServ.set(details);
	
      			}else
      			{
      				Wallet singleWallet=wfs.getAmount(user);		

    				m.addAttribute("single", singleWallet);
    				
    				m.addAttribute("showError", true);
    				
    				return "MyWallet";
      			}
      			
 	   			
 	   			return "redirect:/MyRelations";
      		}
      		
      		return "redirect:/UserLogin";	
      					
          }
        
         @PostMapping("/addMoneyByUser")
       	 public String addMoneyByUser(HttpSession session,@ModelAttribute("bankdetails") bankAccountDetails bankdetails)
          {
        	 
        	 transactions transaction=new transactions();
       		
       		String user=(String) session.getAttribute("email");
       		
       		if(user!=null)
       		{
       			
       			// user wallet Changes
       			Wallet singleUserWallet=wfs.getAmount(user);
      			long userWalletBalance=singleUserWallet.getWalletAmount();
      			long lastAmount=userWalletBalance+bankdetails.getAmount();
      			singleUserWallet.setWalletAmount(lastAmount);
      			// save user wallet Fund
      			wfs.createWallet(singleUserWallet);
      			
       			
       			// current date and time
  				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
  				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss"); 

  				LocalDateTime now = LocalDateTime.now();
  				LocalDateTime now1 = LocalDateTime.now();

  				String currentdate=dtf.format(now);
  				String currenttime=dtf1.format(now1);
       			
       			// generate random number for transaction id
				Random generator = new Random(System. currentTimeMillis()) ;		
				int random=(int) ((generator. nextLong()) % 1000000000);	
				
				// if generate number is negative convert it to positive
				if(random<0){random*=(-1);}
       			
       			// make changes for transactions
       			transaction.setAmount(bankdetails.getAmount());
       			transaction.setReceiver(user);
       			transaction.setSender("Self");
       			transaction.setTransactionid(Integer.toString(random));
       			transaction.setTransdate(currentdate);
				transaction.setTranstime(currenttime);
				// save transaction Details
       			transServ.addTransaction(transaction);
       			
       			// save bank details
       			bankDetails.save(bankdetails);
       			
       			
       			
  	   			return "redirect:/MyWallet";
       		}
       		
       		return "redirect:/UserLogin";	
       					
           }
        
          
          @PostMapping("/withdrawMoneyByUser")
         public String withdrawMoneyByUser(ModelMap m,HttpSession session,@ModelAttribute("bankdetails") bankAccountDetails bankdetails,@RequestParam("withdrawAmount")String withdrawAmount)
            {
          	 
        	  long withdrawableAmount=Integer.parseInt(withdrawAmount);
          	 	transactions transaction=new transactions();
         		
         		String user=(String) session.getAttribute("email");
         		
         		if(user!=null)
         		{
         			
         			// user wallet Changes
         			Wallet singleUserWallet=wfs.getAmount(user);
         			
        			long userWalletBalance=singleUserWallet.getWalletAmount();
        			
        			if(userWalletBalance>=withdrawableAmount)
        			{
	        			long lastAmount=userWalletBalance-withdrawableAmount;
	        			singleUserWallet.setWalletAmount(lastAmount);
	        			// save user wallet Fund
	        			wfs.createWallet(singleUserWallet);
	        			
	         			
	         			// current date and time
	    				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
	    				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm:ss"); 
	
	    				LocalDateTime now = LocalDateTime.now();
	    				LocalDateTime now1 = LocalDateTime.now();
	
	    				String currentdate=dtf.format(now);
	    				String currenttime=dtf1.format(now1);
	         			
	         			// generate random number for transaction id
		  				Random generator = new Random(System. currentTimeMillis()) ;		
		  				int random=(int) ((generator. nextLong()) % 1000000000);	
		  				
		  				// if generate number is negative convert it to positive
		  				if(random<0){random*=(-1);}
	         			
	         			// make changes for transactions
	         			transaction.setAmount(withdrawableAmount);
	         			transaction.setReceiver("Self");
	         			transaction.setSender(user);
	         			transaction.setTransactionid(Integer.toString(random));
	         			transaction.setTransdate(currentdate);
	         			transaction.setTranstime(currenttime);
	         			// save transaction Details
	         			transServ.addTransaction(transaction);
	         			
	         			// save bank details
	         			bankDetails.save(bankdetails);
        			}else
        			{
        				      				
        				Wallet singleWallet=wfs.getAmount(user);		

        				m.addAttribute("single", singleWallet);
        				
        				m.addAttribute("showError", true);
        				
        				return "MyWallet";
        				
        			}
	         			
	         			
	         			
	    	   			return "redirect:/MyWallet";
         		}
         		
         		return "redirect:/UserLogin";	
         					
             }
          
        
        
        
        
        
        
        
        
        
	
	
	
	


	// admin Module

	

	@RequestMapping("/editedALoan")
	public String ApprovePending(@ModelAttribute("pl") ALoan pl,@ModelAttribute("transaction") transactions transaction,@ModelAttribute("adminwallet") AdminWallet adminwallet,@ModelAttribute("details") EmiDetails details, @RequestParam("amount")long amount,ModelMap m) 
	{	

		// all transactions of admin wallet
		List<AdminWallet> getAll=as.getAll();
		
		if(getAll.size()>0)
		{
			// getting  last wallet amount of admin
			AdminWallet singleData=getAll.get(getAll.size()-1);		
			long previousWalletAmount=singleData.getWalletAmount();
			
			if(previousWalletAmount>=amount)
			{		
				// send Money to loan applicant
				if(pl.getLoanstatus().equals("Accepted") && pl.getPaymentstatus().equals("Distributed") )
				{
		
					// generate random number for transaction id
					Random generator = new Random(System. currentTimeMillis()) ;		
					int random=(int) ((generator. nextLong()) % 1000000000);	
					
					// if generate number is negative convert it to positive
					if(random<0){random*=(-1);}
					
					// set transaction Id
					transaction.setTransactionid(Integer.toString(random));
					
					// getting applicant email id
					String user=pl.getEmail();
					
					// getting user wallet info
					Wallet singleApplicantWallet=wfs.getAmount(user);
					
					
					// admin distributed amount
					long transactionAmount=transaction.getAmount();	
			
					// applicant previous wallet amount
					long userOriginalWalletAmount=singleApplicantWallet.getWalletAmount();
					
					// add the distributed amount in applicant wallet
					userOriginalWalletAmount=userOriginalWalletAmount+transactionAmount;			
					singleApplicantWallet.setWalletAmount(userOriginalWalletAmount);
			
					// deduct distributed amount from admin wallet
					long lastAdminAmount=previousWalletAmount-amount;				
					adminwallet.setWalletAmount(lastAdminAmount);
					adminwallet.setTransactionAmount(amount);
					
					// for creating EMI dates
					List<String> EmiDates=new ArrayList<String>();
					
					// for creating EMI Statuses
					List<String> EmiStatus=new ArrayList<String>();
					
					// for Creating Number Of Emi's
					List<Integer> numberOfEmis=new ArrayList<Integer>();
					
					String CurrentDate=pl.getDate();
					String duration=pl.getDuration();
					String durationIn=pl.getDurationunit();
					String day=pl.getSuitableEmiDate();
					
					
					EmiDates=createEmaiDates(CurrentDate,duration,durationIn,day);					
					EmiStatus=createEmaiStatus(duration,"Unpaid");
					numberOfEmis=createEmiNumbers(Integer.parseInt(pl.getDuration()));			

					for(int i=0;i<numberOfEmis.size();i++)
					{
			
						details.setEmail(pl.getEmail());
						details.setEmiNumber(numberOfEmis.get(i));
						details.setEmiDate(EmiDates.get(i));
						details.setEmiStatus(EmiStatus.get(i));
						details.setaLoan(pl);
						// save EMI Dates and Status
						EMISServ.send(details);
						
					}
					
					// save changes of applicant wallet 
					wfs.createWallet(singleApplicantWallet);
					
					// save changes of admin wallet
					as.send(adminwallet);
			
					// save transaction
					transServ.addTransaction(transaction);
					
					// save loan applicant form
					all.getloan(pl);
					
				
				}else 
				{
					all.getloan(pl);
				}
	
				return "redirect:/PendingLDetails";	
				
				
			}
			else 
			{
				
				m.addAttribute("showError", true);
				
				return "AdminHome";
			}
		}else {
			
			m.addAttribute("showError", true);
			
			return "AdminHome";
		}
		
		
	}
	
	
	private List<Integer> createEmiNumbers(int parseInt) 
	{
		List<Integer> map=new ArrayList<Integer>();
		
		for(int i=0;i<parseInt;i++)
		{
			map.add(i+1);
		}
		
		return map;
	}

	private static List<String> createEmaiDates(String CurrentDate, String duration, String durationUnit,String date) 
	{
		List<String> map=new ArrayList<String>();
		
		int selectedDay=Integer.parseInt(date);
		
		
		int CurrentDay=Integer.parseInt(""+CurrentDate.charAt(8)+CurrentDate.charAt(9));

		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		LocalDate date2 = LocalDate.parse(CurrentDate, formatter);
		 
		CurrentDate=correctDate(CurrentDay,CurrentDate,selectedDay,date2);
		

		int Duration=Integer.parseInt(duration);

		for(int i=0;i<Duration;i++)
		{			
			if(durationUnit.equals("Day"))
			{

					// Parse the input date
			        LocalDate date3 = LocalDate.parse(CurrentDate, formatter);
	
					
		            // Increase the date by a specific number of days
		            LocalDate newDate = date3.plusDays(1);
		            
		            // Format the updated date back to dd-MM-yyyy
		            String newDateStr = newDate.format(formatter);
		           
		            
		            map.add(newDateStr);			
					// update the date
					CurrentDate=newDateStr;
					
					
				
				
			}else if(durationUnit.equals("Month"))
			{
				
				// Parse the input date
		        LocalDate date3 = LocalDate.parse(CurrentDate, formatter);

				
				// Increase the date by a specific number of month
	            LocalDate newDate = date3.plusMonths(1);	            
	            // Format the updated date back to dd-MM-yyyy
	            String newDateStr = newDate.format(formatter);	            
	            map.add(CurrentDate);	            
	            // update the date
	            CurrentDate=newDateStr;
	            
			}
			else {
				System.out.println("Enter Duration Unit");
			}
			
		}
		
		

		return map;
	}
	
	private static String correctDate(int CurrentDay, String CurrentDate, int selectedDay, LocalDate date2) 
	{
		
		if(selectedDay==0)
		{
			
			return CurrentDate;
		}		
		else if (CurrentDay<selectedDay)
		{
			
			int x=selectedDay-CurrentDay;			
			// Increase the date by a specific number of days
	         LocalDate newD = date2.plusDays(x);
	         
	         CurrentDate=newD.toString();
		
	         return CurrentDate;
			
		}else if(CurrentDay>selectedDay)
		{
			int x=CurrentDay-selectedDay;
			
			LocalDate newDate = date2.minusDays(x);
			date2=newDate;
			LocalDate newD = date2.plusMonths(1);
			
			CurrentDate=newD.toString();
			
			return CurrentDate;
		}
		else if(CurrentDay==selectedDay)
		{

			LocalDate newD = date2.plusMonths(1);
			
			CurrentDate=newD.toString();
			
			return CurrentDate;
			
		}else {
			
			return CurrentDate;
		}
		
	}
	
	private static List< String> createEmaiStatus(String duration, String string) 
	{
		List<String> map=new ArrayList<String>();
		
		int Duration=Integer.parseInt(duration);
		
		for(int i=0;i<Duration;i++)
		{
			map.add(string);
			
		}
		
		
		return map;
	}
	
	
	
	
	
	@GetMapping("/PendingLDetails")
	public String Pending(Model m) {
		
		List<ALoan> P =all.Getloan("Pending");
		
		if(P.size()>0)
		{
			m.addAttribute("P",P);
		}else {
			m.addAttribute("mssg","Oop's no records are available !!!");
		}
		return "PendingLDetails";
			
	}
	
	@GetMapping("/allApplied")
	public String allappliedlons(Model m) {
		
		List<ALoan> P =all.GetAllLoan();
		
		if(P.size()>0)
		{
			m.addAttribute("P",P);
		}else {
			m.addAttribute("mssg","Oop's no records are available !!!");
		}
		return "allapplied";
			
	}

	
	@GetMapping("/ApprovedLDetails")
	public String Savedata1(Model m) {
		
		List<ALoan>P=all.Getloan("Accepted","Distributed");

		if(P.size()>0)
		{
			m.addAttribute("P",P);
		}else {
			m.addAttribute("mssg","Oop's no records are available !!!");
		}

		return "Approved";
			
	}

	@GetMapping("/ViewSingleLoan")
	public String viewSingleLoan(@RequestParam("id") int id,Model m,HttpSession session)
     {
		String user=(String)session.getAttribute("email");
		if(user!=null)
		{
			ALoan a1= all.GetSingle(id);
			
			m.addAttribute("a1", a1);
			return "ViewSingleLoan";
		}
		
		
		return "AdminLogin";
					
     }
	
	
	
	@RequestMapping("/AdminLog")
	public String AdminLogin( ) 
	{
		
		return "AdminLogin";
		
	}
	
	@PostMapping("/AdminLogin")
	public String AdminLogin1(@RequestParam ("email") String email,@RequestParam ("password") String password, ModelMap m,HttpSession s1) 
	{
		
		if((email.equals("admin@gmail.com") && password.equals("admin")))  
		{
			s1.setAttribute("email", "admin@gmail.com");
			s1.setAttribute("type", "admin");
			return "redirect:/AdminHome";
		}
		m.put("errorMsg", "Please provide correct Admin name and password !!");
		return "AdminLogin";	
	} 
	
	@RequestMapping("/AdminHome")
	public String adminHomePage(HttpSession s1) 
	{
		String checkSession=(String)(s1.getAttribute("email"));
		if(checkSession!=null )
		{
			return "AdminHome";
			
		}else 
		{
			return "AdminLogin";
		}
		
	}

	
	
	

	@RequestMapping("/AdminLogout")
	public String AdminLogOut(HttpSession sess) 
	{
		sess.invalidate();
		return "redirect:/AdminLog";	
	}	

	@RequestMapping("/addMoneyOnWallet")
	public String addMoneyOnWallet(HttpSession session) 
	{
		
		String user=(String) session.getAttribute("type");
		
		if(user.equals("admin"))
		{
			return "addMoney";
		}else if(user!=null)
		{
			return "redirect:/NBFC";
		}
		
		return "AdminLogin";
		
		
	}
	
	@RequestMapping("/sendMoney")
	public String sendMoney(@ModelAttribute("wallet") AdminWallet wallet) 
	{
		List<AdminWallet> getAll=as.getAll();
		
		if(getAll.size()==0)
		{
			wallet.setWalletAmount(0);
			
			long previousWalletAmount=0;
			
			long addedAmount=wallet.getTransactionAmount();
			
			long lastAmount=previousWalletAmount+addedAmount;
			
			wallet.setWalletAmount(lastAmount);

		}

		if(getAll.size()>0)
		{
			AdminWallet singleData=getAll.get(getAll.size()-1);
			
			long previousWalletAmount=singleData.getWalletAmount();
			
			long addedAmount=wallet.getTransactionAmount();
			
			long lastAmount=previousWalletAmount+addedAmount;
			
			wallet.setWalletAmount(lastAmount);
			
		}
		
		as.send(wallet);
		
		return "AdminHome";	
	}
	
	@RequestMapping("/ViewAdminWalletTranctions")
	public String ViewAdminWalletTranctions(ModelMap map) 
	{
		List<AdminWallet> getAll=as.getAll();
		
		map.addAttribute("data", getAll);

		return "AdminWalletTransactions";	
	}
	
	@RequestMapping("/allwallets")
	public String allWallet(ModelMap map) 
	{
		List<Wallet> getAll=wfs.getAllWallets();
		
		map.addAttribute("data", getAll);

		return "allWallets";	
	}
	
	@RequestMapping("/allTransactions")
	public String allTransactions(ModelMap map) 
	{
		List<transactions> getAll=transServ.getAllTransactions();
		
		map.addAttribute("data", getAll);

		return "allTransactions";	
	}
	
	
	
	
	
	
	
	
	
	
	
//previous code
	
	
//	@GetMapping("/addFundToApplicantWallet")
//	public String addFund(Model m)
//     {
//		String loanstatus="Approved";
//		String paymentstatus="Processing";
//		
//		List<ALoan> a1=all.getLoans(loanstatus,paymentstatus);
//		
//		if(a1.size()>0)
//		{
//			m.addAttribute("a1",a1);
//		}else {
//			m.addAttribute("mssg","Oop's no records are available !!!");
//		}
//		
//		return "allLoansWithProcessingPayment";
//					
//     }
	
     
//     @GetMapping("/addMoney")
// 	 public String addMoney(@RequestParam("id") int id,Model m)
//      {
//    	 ALoan a1= all.GetSingle(id);
//    	 
//    	 m.addAttribute("a1", a1);
// 		
// 		return "distributeAmountToWallet";
// 					
//      }
     

      
	
//	@GetMapping("/processing")
//	public String PamentProcessing(@RequestParam("id") int id,Model m)
//     {
//		approve p1= aps.GetPen(id) ;
//		m.addAttribute("p1",p1);
//		return "PaymentProcessing";
//					
//     }
	

//	@GetMapping("/ApprovePending")
//	public String ApprovePending(@RequestParam("id") int id)
//     {
//		ALoan a1= all.GetSingle(id);
//		
//		a1.setLoanstatus("Approved");
//		a1.setPaymentstatus("Processing");
//		all.getloan(a1);
//	
//		return "redirect:/PendingLDetails";
//					
//     }
//	
//	@GetMapping("/RejectPending")
//	public String deletepending(@RequestParam("id") int id)
//     {
//		
//		ALoan a1= all.GetSingle(id);
//		
//		a1.setLoanstatus("Rejected");
//		a1.setPaymentstatus("Stoped");
//		all.getloan(a1);
//		
//		
//		return "redirect:/PendingLDetails";
//					
//     }
	

//	@GetMapping("/deleteApl")
//	public String delete(@RequestParam("id") int id)
//     {
//		all.deletedata(id);
//		return "redirect:/LoanApproval";
//					
//     }
//	@GetMapping("/editAppl")
//	public String edit(@RequestParam("id") int id,Model m)
//     {
//		ALoan s= all.getone(id);
//		m.addAttribute("s",s);
//		return "ApproveLoan";
//					
//     }
	

	
//	@GetMapping("/deleteCust")
//	public String deleteAppli(@RequestParam("id") int id)
//     {
//		asa.deleteApplicant(id);
//		return "redirect:/CustomersRegDetails";
//					
//     }

	
//	@RequestMapping("/CustomersRegDetails")
//	public String AddApplicant(Model m) 
//	{
//	    
//		List<Applicant> Ap=asa.getappli();
//		m.addAttribute("Ap",Ap);
//		
//		return "CustomersRegDetails";
//			
//	}
	
	
//	@RequestMapping("/AddApplicant")
//	public String AddApplicant() {
//		
//		return "AddApplicant";	
//	}
//	
//	@PostMapping("/AddApplicant")
//	public String AddApplicant2(@ModelAttribute("a") Applicant a) 
//	{
//		asa.addApplicant(a);
//		
//		return "AdminHome";
//			
//	}
	

//	@RequestMapping("/Payment")
//	public String PaymentProcessing(@ModelAttribute("p1") Payment p1 ) {
//		
//		Payment pay= new Payment();
//		pay.setId(p1.getId());
//		pay.setAname(p1.getAname());
//		pay.setAemail(p1.getAemail());
//		
//        prc.payment(p1);
//      
//		return "redirect:/PaymentSuccessfulTable";		
//	}
	
//	@GetMapping("/PaymentSuccessfulTable")
//	public String SavePaymentdata(Model m) {
//		
//		List<Payment>p=prc.getpayment();
//		m.addAttribute("p",p);
//		return "PaymentSuccessfulTable";
//			
//	}
	
//  @GetMapping("/sendMoneyInWallet")
//	  public String sendMoneyInwallet(@ModelAttribute("wall") Wallet wall)
//   {
//	  wall.set
// 	 
//	  wfs.sendMoney(wall);
//
//		return "redirect:/addFundToApplicantWallet";
//					
//   }

	

	
//	@GetMapping("/deleteAplicant")
//	public String deleteapl(@RequestParam("id") int id)
//     {
//		aps.deletedata(id);
//		return "redirect:/Approved";
//					
//     }
	
	
//	@RequestMapping("/Addpending")
//	public String Addpen(@ModelAttribute("aa") approve aa) {
//		
//            PendingLoan al= new PendingLoan();
//		al.setId(aa.getId());
//		al.setAname(aa.getAname());
//		al.setAemail(aa.getAemail());
//		al.setAphone(aa.getAphone());
//		al.setAaddress(aa.getAaddress());
//		al.setOccupation(aa.getOccupation());
//		al.setGender(aa.getGender());
//		al.setStatus(aa.getStatus());
//		al.setIncome(aa.getIncome());
//		al.setEmioption(aa.getEmioption());
//		al.setLoanamount(aa.getLoanamount());
//		al.setRate(aa.getRate());
//		al.setFinalamount(aa.getFinalamount());
//		al.setPurpose(aa.getPurpose());
//		al.setDependent(aa.getDependent());
//		
//         pls.Pendloan(al);
//		return "redirect:/PendingLDetails";		
//	}
	

//	@PostMapping("/Next")
//	public String WalletFunds1(@ModelAttribute() Wallet w) 
//	{
//		wfs.getwallet(w);
//		return "AdminHome";
//		
//	}
	
	
//	@RequestMapping("/Wallet")
//	public String WalletTable(ModelMap m) 
//	{
//		List<Wallet> w1=wfs.addwallet();
//		m.addAttribute("w1",w1);
//		return "WalletTable";
//	}
	
	
//	@RequestMapping("/viewApplicant")
//	public String ViewApplicant() {
//		return "ViewEditApplicant";	
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
// required
	
//	@RequestMapping("/WalletFunds")
//	public String WalletFunds() 
//	{
//
//		return "WalletFunds";	
//	}
		
//	@RequestMapping("/EMI")
//	public String EMI() {
//		return "EMICalculator";	
//	}
	
	
//	@RequestMapping("/DocumentVerification")
//	public String DocumentVerification() {
//		return "DocumentVerification";	
//	}
	
	
//	@RequestMapping("/LoanApproval")
//	public String LoanStatus(ModelMap m) 
//	{
//		List<ALoan> a1=all.dispstatus();
//		
//		
//		if(a1.size()>0)
//		{
//			m.addAttribute("a1",a1);
//		}else {
//			m.addAttribute("mssg","Oop's no records are available !!!");
//		}
//
//		return "LoanApproval";	
//	}
	
}

