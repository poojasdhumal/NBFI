package com.example.demo.service;

import com.example.demo.modules.bankAccountDetails;

public interface bankAccountDeatailsServ 
{

	void save(bankAccountDetails bankdetails);

}
