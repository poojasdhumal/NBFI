package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.approve;

public interface approveService {

	void myinfo(approve aa);
	
	List<approve>app();
	
	
	
	approve GetPen(int id);

	void deletedata(int id);
}
