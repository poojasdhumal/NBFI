package com.example.demo.modules;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class EmiDetails 
{
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String email;
	private int emiNumber;
	private String emiDate;
	private String emiStatus;
	private String paidDate;
	@ManyToOne
    @JoinColumn(name = "aLoan_id")
    private ALoan aLoan;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getEmiNumber() {
		return emiNumber;
	}
	public void setEmiNumber(int emiNumber) {
		this.emiNumber = emiNumber;
	}
	public String getEmiDate() {
		return emiDate;
	}
	public void setEmiDate(String emiDate) {
		this.emiDate = emiDate;
	}
	public String getEmiStatus() {
		return emiStatus;
	}
	public void setEmiStatus(String emiStatus) {
		this.emiStatus = emiStatus;
	}
	public String getPaidDate() {
		return paidDate;
	}
	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}
	public ALoan getaLoan() {
		return aLoan;
	}
	public void setaLoan(ALoan aLoan) {
		this.aLoan = aLoan;
	}
	@Override
	public String toString() {
		return "EmiDetails [id=" + id + ", email=" + email + ", emiNumber=" + emiNumber + ", emiDate=" + emiDate
				+ ", emiStatus=" + emiStatus + ", paidDate=" + paidDate + ", aLoan=" + aLoan + "]";
	}

	
	
	
	

}
