package com.example.demo.dao;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.Applicant;
import com.example.demo.repo.ApplicantRepo;
import com.example.demo.service.ApplicantService;

@Service
public class ApplicantDao implements ApplicantService
{
	@Autowired
     ApplicantRepo ar;
	@Override
	public void addApplicant(Applicant a) {
		
		ar.save(a);
	}
	@Override
	public List<Applicant> getappli() {
		
		return ar.findAll();
	}
	@Override
	public void deleteApplicant(int id) {
		
		ar.deleteById(id);
		
	}
	@Override
	public Applicant EditApplicant(int id) {
		Applicant ap=ar.getById(id);
		return ap;
	}

	@Override
	public Applicant Checklogin(String email) {
		
		return ar.getByEmail(email);
	}
	
}
