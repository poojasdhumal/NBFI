package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modules.ALoan;
import com.example.demo.repo.ALoanRepo;
import com.example.demo.service.ALoanService;
@Service
public class ALoanDao implements ALoanService
{
    @Autowired
	ALoanRepo arr;
    
	@Override
	public void getloan(ALoan al) {
		
		arr.save(al);
		
	}
	@Override
	public List<ALoan> dispstatus() {
		
		return arr.findAll();
	}


	@Override
	public List<ALoan> Getloan(String loanstatus,String paymentstatus) 
	{
		
		return arr.findByLoanstatusAndPaymentstatus(loanstatus,paymentstatus);
	}
	@Override
	public ALoan GetSingle(int id) 
	{
		
		return arr.getById(id);
	}
	
	@Override
	public List<ALoan> getLoans(String loanstatus, String paymentstatus) 
	{
		
		return arr.findByLoanstatusAndPaymentstatus(loanstatus,paymentstatus);
	}
	@Override
	public List<ALoan> getLoans(String email) 
	{
		
		return arr.getByEmail(email);
	}
	@Override
	public List<ALoan> GetAllLoan() 
	{
		
		return arr.findAll();
	}
	@Override
	public List<ALoan> Getloan(String status) 
	{
		
		return arr.findByLoanstatus(status);
	}
	@Override
	public List<ALoan> getApproverdLoans(String user, String loanStatus, String paymentStatus) 
	{
		
		return arr.findByEmailAndLoanstatusAndPaymentstatus(user,loanStatus,paymentStatus);
	}

}
