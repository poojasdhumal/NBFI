package com.example.demo.modules;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AdminWallet 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private long WalletAmount;
	private long TransactionAmount;
	private String creditordebit;
	private String transtime;
	private String transdate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getWalletAmount() {
		return WalletAmount;
	}
	public void setWalletAmount(long walletAmount) {
		WalletAmount = walletAmount;
	}
	public long getTransactionAmount() {
		return TransactionAmount;
	}
	public void setTransactionAmount(long transactionAmount) {
		TransactionAmount = transactionAmount;
	}
	public String getCreditordebit() {
		return creditordebit;
	}
	public void setCreditordebit(String creditordebit) {
		this.creditordebit = creditordebit;
	}
	public String getTranstime() {
		return transtime;
	}
	public void setTranstime(String transtime) {
		this.transtime = transtime;
	}
	public String getTransdate() {
		return transdate;
	}
	public void setTransdate(String transdate) {
		this.transdate = transdate;
	}
	@Override
	public String toString() {
		return "AdminWallet [id=" + id + ", WalletAmount=" + WalletAmount + ", TransactionAmount=" + TransactionAmount
				+ ", creditordebit=" + creditordebit + ", transtime=" + transtime + ", transdate=" + transdate + "]";
	}
	
	
	
}
