package com.example.demo.service;

import java.util.List;

import com.example.demo.modules.ALoan;

public interface ALoanService 
{
  void getloan(ALoan al);
  
  List<ALoan>dispstatus();

	List<ALoan> Getloan(String status, String string);

	ALoan GetSingle(int id);

	List<ALoan> getLoans(String loanstatus, String paymentstatus);

	List<ALoan> getLoans(String email);

	List<ALoan> GetAllLoan();

	List<ALoan> Getloan(String status);

	List<ALoan> getApproverdLoans(String user, String string, String string2);
	
}
